package com.myproject.sportyshoes.service.impl;

import com.myproject.sportyshoes.model.Purchase;

import com.myproject.sportyshoes.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PurchaseServiceImpl {

    @Autowired
    PurchaseRepository repo;

    public Purchase savePurchase(Purchase purchase) {
        return repo.save(purchase);
    }

    public String findByDate(String date) {
        return repo.findByDate(date);
    }

    public String findByPro_id(long pro_id){
        return repo.findByPro_id(pro_id);
    }


}