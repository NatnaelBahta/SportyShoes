package com.myproject.sportyshoes.controller;

import com.myproject.sportyshoes.model.Category;
import com.myproject.sportyshoes.service.CategoryService;;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }
    // build get all categories REST API
    @GetMapping("/getAll")
    public List<Category> getAllCategory(){
        return categoryService.getAllCategories();
    }

    // build get category by id REST API
    @GetMapping("/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable ("id")long categoryId){
        return new ResponseEntity<Category>(categoryService.getCategoryById(categoryId), HttpStatus.OK);
    }

    // build update category REST API
    @PutMapping("/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable("id") long id
            ,@RequestBody Category category){
        return new ResponseEntity<Category>(categoryService.updateCategory(category,id), HttpStatus.OK);

    }

    // build delete category REST API
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCategory(@PathVariable("id") long id){

        // delete category from DB
        categoryService.deleteCategory(id);

        return new ResponseEntity<String>("Category deleted successfully!", HttpStatus.OK);
    }
}
