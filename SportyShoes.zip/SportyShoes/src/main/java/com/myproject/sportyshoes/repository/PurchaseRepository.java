package com.myproject.sportyshoes.repository;

import com.myproject.sportyshoes.model.Purchase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface PurchaseRepository extends JpaRepository<Purchase, Long> {

    @Query("select d.date from Purchase d where d.date=:date")
    public String findByDate(String date);

    @Query("select p.pro_id from Purchase p where p.pro_id=:pro_id")
    public String findByPro_id(long pro_id);
}


