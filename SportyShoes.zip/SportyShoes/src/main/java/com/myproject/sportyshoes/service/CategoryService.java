package com.myproject.sportyshoes.service;

import com.myproject.sportyshoes.model.Category;

import java.util.List;

public interface CategoryService {

    Category saveCategory(Category category);
    List<Category> getAllCategories();
    Category getCategoryById(long id);
    Category updateCategory(Category category, long id);
    void deleteCategory(long id);

}

