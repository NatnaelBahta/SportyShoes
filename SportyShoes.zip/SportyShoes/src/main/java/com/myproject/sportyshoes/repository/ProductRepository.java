package com.myproject.sportyshoes.repository;

import com.myproject.sportyshoes.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
