package com.myproject.sportyshoes.security;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


@EnableWebSecurity
public class SpringSecurityConfiguration extends WebSecurityConfigurerAdapter  {

    // Adding the roles
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
                .withUser("natu")
                .password("pass")
                .roles("admin_role")
                .and()
                .withUser("user")
                .password("pass1")
                .roles("user_role");
    }

    // Configuring the api
    // according to the roles.
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.
                httpBasic()
                .and()
                .authorizeRequests()
                .antMatchers("/api/admin/users/getAll").hasRole("admin_role")
                .antMatchers("/api/admin/users/{id}").hasRole("admin_role")
                .antMatchers("/api/admin/products/getAll").hasRole("admin_role")
                .antMatchers("/api/admin/products/{id}").hasRole("admin_role")
                .antMatchers("/api/admin/purchase/{date}").hasRole("admin_role")
                .antMatchers("/api/admin/purchase/{pro_id}").hasRole("admin_role")
                .and()
                .formLogin();
    }

    // Function to encode the password
    // assign to the particular roles.
    @Bean
    public PasswordEncoder getPasswordEncoder(){
        return NoOpPasswordEncoder.getInstance();
    }
}



