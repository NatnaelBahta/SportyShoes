package com.myproject.sportyshoes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.myproject.sportyshoes.model.User;
import com.myproject.sportyshoes.service.AdminService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
@RequestMapping("/api/admin/users")
public class UserController {
    @Autowired
    private AdminService adminService;

    public UserController(AdminService adminService) {
        this.adminService = adminService;
    }
 //build create user REST API
    @PostMapping("/save")
    public ResponseEntity<User> saveUser(@RequestBody User user){
          return new ResponseEntity<User>(adminService.saveUser(user), HttpStatus.CREATED);
    }
// build get all users REST API
    @GetMapping("/getAll")
      public List<User> getAllUsers(){
        return adminService.getAllUsers();
      }

// build get user by id REST API
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable ("id")long userId) {
        return new ResponseEntity<User>(adminService.getUserById(userId), HttpStatus.OK);
    }


// build update user REST API
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable("id") long id
                                          ,@RequestBody User user){
        return new ResponseEntity<User>(adminService.updateUser(user,id), HttpStatus.OK);

    }

    // build delete user REST API
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") long id){

      // delete user from DB
        adminService.deleteUser(id);

        return new ResponseEntity<String>("User deleted successfully!", HttpStatus.OK);
    }

}



