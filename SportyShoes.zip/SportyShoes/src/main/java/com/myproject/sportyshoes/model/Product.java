package com.myproject.sportyshoes.model;




import javax.persistence.*;


@Entity
@Table (name = "Products")
public class Product {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long pro_id;
    private String name;
    private String description;
    private int price;
    private long cat_id;




    public long getPro_id() {
        return pro_id;
    }

    public void setPro_id(long pro_id) {
        this.pro_id = pro_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
//
    public long getCat_id() {
        return cat_id;
    }

    public void setCat_id(long cat_id) {
        this.cat_id = cat_id;
    }






}

