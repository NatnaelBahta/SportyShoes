package com.myproject.sportyshoes.service.impl;

import com.myproject.sportyshoes.Exception.ResourceNotFoundException;
import com.myproject.sportyshoes.model.Category;
import com.myproject.sportyshoes.model.Product;
import com.myproject.sportyshoes.repository.CategoryRepository;
import com.myproject.sportyshoes.service.CategoryService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {
    private CategoryRepository categoryRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Category saveCategory(Category category) {
     return categoryRepository.save(category);
    }

    @Override
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public Category getCategoryById(long id) {
        return categoryRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Category", "Id", id));
    }

    @Override
    public Category updateCategory(Category category, long id) {
         // we need to check whether the category with given id exists in DB or not
                Category existingCategory = categoryRepository.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("Category", "Id", id));

        existingCategory.setName(category.getName());
        // save existing category to DB
        categoryRepository.save(existingCategory);
        return existingCategory;
    }

    @Override
    public void deleteCategory(long id) {

        // check whether a category exist in a DB or not
        categoryRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Category", "Id", id));

        categoryRepository.deleteById(id);
    }


}
