package com.myproject.sportyshoes.repository;

import com.myproject.sportyshoes.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository <User, Long> {

}