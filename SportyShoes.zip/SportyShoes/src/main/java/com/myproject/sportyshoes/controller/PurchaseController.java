package com.myproject.sportyshoes.controller;

import com.myproject.sportyshoes.model.Purchase;
import com.myproject.sportyshoes.service.impl.PurchaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/purchase")
public class PurchaseController {

    @Autowired
    PurchaseServiceImpl service;

    @PostMapping("/save")
    public ResponseEntity<Object> savePurchase(@RequestBody Purchase purchase){
        Purchase purchase1= (Purchase) service.savePurchase(purchase);

        if(purchase1!=null)
                return  new ResponseEntity<Object>(purchase1,HttpStatus.CREATED);
		else
                return new ResponseEntity<Object>("Error while inserting data",
                            HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @GetMapping("/{date}")
    public ResponseEntity<String> findPurchase(@PathVariable String date){
        String resp= service.findByDate(date);

        if(resp!=null)
            return new ResponseEntity<String>(resp,HttpStatus.FOUND);
        else
            return new ResponseEntity<String>("Purchase not available",HttpStatus.NOT_FOUND);
    }

    @GetMapping("/{pro_id}")
    public ResponseEntity<String> findByPro_id(@PathVariable long pro_id){
        String resp= service.findByPro_id(pro_id);

        if(resp!=null)
            return new ResponseEntity<String>(resp,HttpStatus.FOUND);
        else
            return new ResponseEntity<String>("Purchase not available",HttpStatus.NOT_FOUND);
    }





}

