package com.myproject.sportyshoes.controller;


import com.myproject.sportyshoes.model.Product;
import com.myproject.sportyshoes.model.Product;
import com.myproject.sportyshoes.service.ProductService;
import com.myproject.sportyshoes.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }
    //build create product REST API
    @PostMapping("/save")
    public ResponseEntity<Product> saveProduct(@RequestBody Product product){
        return new ResponseEntity<Product>(productService.saveProduct(product), HttpStatus.CREATED);
    }
    // build get all products REST API
    @GetMapping("/getAll")
    public List<Product> getAllProducts(){
        return productService.getAllProducts();
    }

    // build get product by id REST API
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable ("id")long productId){
        return new ResponseEntity<Product>(productService.getProductById(productId), HttpStatus.OK);
    }

    // build update product REST API
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable("id") long id
            ,@RequestBody Product product){
        return new ResponseEntity<Product>(productService.updateProduct(product,id), HttpStatus.OK);

    }

    // build delete product REST API
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable("id") long id){

        // delete product from DB
        productService.deleteProduct(id);

        return new ResponseEntity<String>("Product deleted successfully!", HttpStatus.OK);
    }






}
