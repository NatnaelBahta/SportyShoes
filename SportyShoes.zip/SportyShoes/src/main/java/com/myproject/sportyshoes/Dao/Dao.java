package com.myproject.sportyshoes.Dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Dao {

    public Connection con = null;
    public Statement st = null;

    public Dao() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
//        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/SportyShoes", "root", "nathnael");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/SportyShoes", "root", "nathnael");
        System.out.println("connection established with database");

        st = con.createStatement();
    }

}
